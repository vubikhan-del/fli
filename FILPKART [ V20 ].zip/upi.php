<?php
$upi = 'Vev';
$transaction_id = 'Beebb';
$merchant_code = 'Bdbbd';
?>